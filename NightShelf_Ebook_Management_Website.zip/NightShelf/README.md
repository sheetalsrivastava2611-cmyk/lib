# NightShelf — E-Book Management Website

A beginner-friendly e-book library built with HTML, CSS, JavaScript and Supabase.

## Features
- Student sign-up/sign-in and PDF access
- Admin-only add, edit and delete book records
- Search by title, author, subject or description
- Category filter and dashboard statistics
- Private PDF storage with short-lived signed links
- Responsive dark theme

## 1. Create the Supabase backend
1. Go to https://supabase.com and create a free project.
2. Open **SQL Editor → New query**.
3. Open `schema.sql`, copy all its contents, paste into SQL Editor and click **Run**.
4. Open **Project Settings → API** (or **Data API**) and copy the Project URL and anon/public key.
5. Paste them into `config.js`:
   - `SUPABASE_URL` = Project URL
   - `SUPABASE_ANON_KEY` = anon/public key
6. Never put a `service_role` or secret key in browser code or GitHub.

## 2. Run the website on your computer
- Put all files in one folder.
- Open the folder in VS Code.
- Install the **Live Server** extension.
- Right-click `index.html` → **Open with Live Server**.
- The site needs an internet connection to contact Supabase.

## 3. Create the first admin account
1. Open your site and click **Sign in → Create a student account**.
2. Register with your own email and password. Confirm the email if Supabase asks.
3. Sign in once.
4. In Supabase, open **SQL Editor → New query** and run this command, replacing the email:
   `update public.profiles set role = 'admin' where email = 'you@example.com';`
5. Refresh the website. The Manage collection option should appear.
6. Keep your admin account private. Other sign-ups automatically receive the student role.

## 4. Add books
1. Sign in as admin.
2. Open **Manage collection**.
3. Enter title, author, category and description.
4. Choose a PDF (optional) and click **Add e-book**.
5. Students can sign in and click **Open PDF**. The PDF is stored in a private bucket and opened through a temporary signed link.

Only upload PDFs you own or have permission to distribute.

## 5. Push to GitHub
1. Create a new repository on https://github.com (e.g. `nightshelf-ebook-library`).
2. In VS Code, open Terminal in the project folder and run:

   ```bash
   git init
   git add .
   git commit -m "Build NightShelf e-book library"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/nightshelf-ebook-library.git
   git push -u origin main
   ```

3. Replace `YOUR-USERNAME` with your GitHub username.
4. `config.js` contains the Supabase anon/public key. That key is designed to be public, but your database must keep RLS enabled and policies in `schema.sql`. Never publish a service-role key or a user's password.

## 6. Deploy on Vercel
1. Go to https://vercel.com and sign in with GitHub.
2. Click **Add New → Project**.
3. Import `nightshelf-ebook-library`.
4. Framework Preset: **Other**. Build Command: leave blank. Output Directory: `.`.
5. Click **Deploy**.
6. Open the generated website URL and test sign-in, searching and PDF access.

When you update files, commit and push to GitHub; Vercel will redeploy automatically.

## Troubleshooting
- **Setup required:** check the URL and anon key in `config.js`, then refresh.
- **Sign-up confirmation:** check your email and confirm before signing in.
- **No admin controls:** run the admin promotion SQL using the exact registered email, then sign out/in or refresh.
- **Permission denied:** re-run `schema.sql` in Supabase SQL Editor and check that all policies were created.
- **PDF won't open:** confirm a PDF was uploaded and the user is signed in.
- **Do not disable RLS** to fix permission errors. Correct the policies instead.

## Project structure
- `index.html` — page layout
- `styles.css` — dark theme and responsive design
- `app.js` — authentication, search, CRUD and PDF handling
- `config.js` — Supabase public project settings
- `schema.sql` — database tables, storage bucket and security policies

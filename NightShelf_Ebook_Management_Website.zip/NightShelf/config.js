// Supabase project settings. These values are safe to use in a browser
// when Row Level Security (RLS) is enabled. NEVER put a service_role key here.
window.SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
window.SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";

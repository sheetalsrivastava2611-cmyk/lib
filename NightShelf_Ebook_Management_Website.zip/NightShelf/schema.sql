-- Run this entire script in Supabase Dashboard > SQL Editor > New query.
-- Creates student/admin profiles, e-book records, a private PDF bucket and secure policies.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- SECURITY DEFINER helper avoids recursive profile-table RLS checks.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create table if not exists public.books (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  author text not null,
  category text not null,
  description text default '',
  file_path text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.books enable row level security;

create policy "Users can read their own profile"
on public.profiles for select to authenticated
using (auth.uid() = id);

create policy "Admins can read all profiles"
on public.profiles for select to authenticated
using (public.is_admin());

create policy "Anyone can read book records"
on public.books for select
using (true);

create policy "Admins can insert books"
on public.books for insert to authenticated
with check (public.is_admin());

create policy "Admins can update books"
on public.books for update to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Admins can delete books"
on public.books for delete to authenticated
using (public.is_admin());

-- Private bucket: students must sign in; only admins can upload/delete.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('ebook-pdfs', 'ebook-pdfs', false, 20971520, array['application/pdf'])
on conflict (id) do update set public = false, file_size_limit = 20971520, allowed_mime_types = array['application/pdf'];

create policy "Signed-in users can read ebook files"
on storage.objects for select to authenticated
using (bucket_id = 'ebook-pdfs');

create policy "Admins can upload ebook files"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'ebook-pdfs'
  and public.is_admin()
);

create policy "Admins can update ebook files"
on storage.objects for update to authenticated
using (
  bucket_id = 'ebook-pdfs'
  and public.is_admin()
)
with check (
  bucket_id = 'ebook-pdfs'
  and public.is_admin()
);

create policy "Admins can delete ebook files"
on storage.objects for delete to authenticated
using (
  bucket_id = 'ebook-pdfs'
  and public.is_admin()
);

-- IMPORTANT: after creating your own account, promote it to admin using:
-- update public.profiles set role = 'admin' where email = 'YOUR_EMAIL_ADDRESS';

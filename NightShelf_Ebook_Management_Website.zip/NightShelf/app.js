const $ = (id) => document.getElementById(id);
const hasConfig = window.SUPABASE_URL && window.SUPABASE_ANON_KEY &&
  !window.SUPABASE_URL.includes("PASTE_") && !window.SUPABASE_ANON_KEY.includes("PASTE_");
const supabase = hasConfig
  ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY)
  : null;

let currentUser = null;
let currentRole = "guest";
let books = [];
let authMode = "signin";
const BUCKET = "ebook-pdfs";
const MAX_FILE_SIZE = 20 * 1024 * 1024;

function notify(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}
function setConnection(online, text) {
  $("connectionText").textContent = text;
  $("connectionText").previousElementSibling.classList.toggle("online", online);
}
function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[c]);
}
function showMessage(id, text, isError = false) {
  $(id).textContent = text;
  $(id).style.color = isError ? "var(--danger)" : "var(--accent2)";
}
function updateAccountUI() {
  $("userLabel").textContent = currentUser ? currentUser.email : "Not signed in";
  $("authButton").textContent = currentUser ? "Sign out" : "Sign in";
  $("accessRole").textContent = currentRole === "admin" ? "Admin" : currentRole === "student" ? "Student" : "Guest";
  $("accessHint").textContent = currentRole === "admin" ? "Can manage records" : currentRole === "student" ? "Can read available PDFs" : "Sign in to access files";
  document.querySelectorAll(".admin-only").forEach(el => el.classList.toggle("hidden", currentRole !== "admin"));
  if (currentRole !== "admin") $("manageSection").classList.add("hidden");
}
async function loadProfile() {
  if (!currentUser) { currentRole = "guest"; updateAccountUI(); return; }
  const { data, error } = await supabase.from("profiles").select("role").eq("id", currentUser.id).single();
  currentRole = !error && data?.role === "admin" ? "admin" : "student";
  updateAccountUI();
}
async function loadBooks() {
  if (!supabase) {
    $("bookGrid").innerHTML = '<div class="empty-state">Add your Supabase URL and anon key in <b>config.js</b>, then reload this page.</div>';
    $("totalBooks").textContent = "0"; $("totalCategories").textContent = "0";
    return;
  }
  const { data, error } = await supabase.from("books").select("*").order("created_at", {ascending:false});
  if (error) {
    $("bookGrid").innerHTML = '<div class="empty-state">Could not load records. Check your database setup and connection.</div>';
    console.error(error); return;
  }
  books = data || [];
  $("totalBooks").textContent = books.length;
  $("totalCategories").textContent = new Set(books.map(b => b.category)).size;
  const categories = [...new Set(books.map(b => b.category).filter(Boolean))].sort();
  const selected = $("categoryFilter").value;
  $("categoryFilter").innerHTML = '<option value="">All categories</option>' + categories.map(c => `<option value="${escapeHTML(c)}">${escapeHTML(c)}</option>`).join("");
  $("categoryFilter").value = categories.includes(selected) ? selected : "";
  renderBooks();
}
function renderBooks() {
  const query = $("searchInput").value.trim().toLowerCase();
  const category = $("categoryFilter").value;
  const filtered = books.filter(b => {
    const match = [b.title,b.author,b.category,b.description].join(" ").toLowerCase().includes(query);
    return match && (!category || b.category === category);
  });
  if (!filtered.length) {
    $("bookGrid").innerHTML = '<div class="empty-state">No e-books found. Try another search or category.</div>'; return;
  }
  $("bookGrid").innerHTML = filtered.map(b => `
    <article class="book-card">
      <div class="book-top"><div class="book-icon">▤</div><span class="category-tag">${escapeHTML(b.category)}</span></div>
      <h3>${escapeHTML(b.title)}</h3><div class="book-author">By ${escapeHTML(b.author)}</div>
      <p class="book-description">${escapeHTML(b.description || "No description added yet.")}</p>
      <div class="card-actions">
        <button class="btn btn-primary btn-small" data-action="read" data-id="${b.id}">Open PDF</button>
        ${currentRole === "admin" ? `<button class="btn btn-quiet btn-small" data-action="edit" data-id="${b.id}">Edit</button><button class="btn btn-danger btn-small" data-action="delete" data-id="${b.id}">Delete</button>` : ""}
      </div>
    </article>`).join("");
}
async function openBook(id) {
  const book = books.find(b => b.id === id);
  if (!book?.file_path) { notify("No PDF has been uploaded for this book yet."); return; }
  if (!currentUser) { notify("Please sign in to open e-books."); $("authDialog").showModal(); return; }
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(book.file_path, 60);
  if (error) { notify("Could not open PDF. Check storage permissions."); console.error(error); return; }
  window.open(data.signedUrl, "_blank", "noopener,noreferrer");
}
function resetBookForm() {
  $("bookForm").reset(); $("bookId").value = ""; $("saveBookButton").textContent = "Add e-book";
}
function editBook(id) {
  const b = books.find(x => x.id === id); if (!b) return;
  $("bookId").value = b.id; $("bookTitle").value = b.title; $("bookAuthor").value = b.author;
  $("bookCategory").value = b.category; $("bookDescription").value = b.description || "";
  $("saveBookButton").textContent = "Save changes";
  $("manageSection").classList.remove("hidden");
  $("manageSection").scrollIntoView({behavior:"smooth"});
}
async function deleteBook(id) {
  const book = books.find(x => x.id === id); if (!book) return;
  if (!confirm(`Delete "${book.title}" from the library?`)) return;
  const { error } = await supabase.from("books").delete().eq("id", id);
  if (error) { notify("Delete failed. Check admin permissions."); console.error(error); return; }
  if (book.file_path) {
    const { error: storageError } = await supabase.storage.from(BUCKET).remove([book.file_path]);
    if (storageError) console.warn("PDF cleanup failed:", storageError);
  }
  notify("Book record deleted."); await loadBooks();
}
async function saveBook(event) {
  event.preventDefault();
  if (currentRole !== "admin") return;
  const id = $("bookId").value;
  const file = $("bookFile").files[0];
  if (file && (file.type !== "application/pdf" || file.size > MAX_FILE_SIZE)) {
    showMessage("adminMessage", "Choose a PDF file smaller than 20 MB.", true); return;
  }
  const record = {
    title: $("bookTitle").value.trim(), author: $("bookAuthor").value.trim(),
    category: $("bookCategory").value.trim(), description: $("bookDescription").value.trim()
  };
  showMessage("adminMessage", "Saving…");
  let filePath = books.find(b => b.id === id)?.file_path || null;
  if (file) {
    const safeName = file.name.toLowerCase().replace(/[^a-z0-9._-]/g, "-");
    const newPath = `${currentUser.id}/${crypto.randomUUID()}-${safeName}`;
    const { error: uploadError } = await supabase.storage.from(BUCKET).upload(newPath, file, {contentType:"application/pdf", upsert:false});
    if (uploadError) { showMessage("adminMessage", uploadError.message, true); return; }
    if (filePath) await supabase.storage.from(BUCKET).remove([filePath]);
    filePath = newPath;
  }
  record.file_path = filePath;
  let result;
  if (id) result = await supabase.from("books").update(record).eq("id", id);
  else result = await supabase.from("books").insert(record);
  if (result.error) {
    showMessage("adminMessage", result.error.message, true);
    // If metadata save fails after upload, remove the newly uploaded file.
    if (file && filePath) await supabase.storage.from(BUCKET).remove([filePath]);
    return;
  }
  showMessage("adminMessage", "Book saved successfully.");
  resetBookForm(); await loadBooks();
}
async function refreshSession() {
  if (!supabase) { setConnection(false, "Setup required"); return; }
  setConnection(true, "Connected to Supabase");
  const { data } = await supabase.auth.getSession();
  currentUser = data.session?.user || null;
  await loadProfile(); await loadBooks();
  supabase.auth.onAuthStateChange((_event, session) => {
    currentUser = session?.user || null;
    setTimeout(async () => { await loadProfile(); await loadBooks(); }, 0);
  });
}
function openAuth(mode) {
  authMode = mode; $("authTitle").textContent = mode === "signin" ? "Sign in" : "Create account";
  $("authSubtitle").textContent = mode === "signin" ? "Sign in to read and manage your library." : "Create a student account to access the collection.";
  $("authSubmit").textContent = mode === "signin" ? "Sign in" : "Create account";
  $("toggleAuthMode").textContent = mode === "signin" ? "New here? Create a student account" : "Already registered? Sign in";
  $("authDialog").showModal();
}
async function handleAuth(event) {
  event.preventDefault();
  const email = $("authEmail").value.trim(), password = $("authPassword").value;
  showMessage("authMessage", "Please wait…");
  const result = authMode === "signin"
    ? await supabase.auth.signInWithPassword({email,password})
    : await supabase.auth.signUp({email,password});
  if (result.error) { showMessage("authMessage", result.error.message, true); return; }
  if (authMode === "signup" && !result.data.session) {
    showMessage("authMessage", "Account created. Check your email to confirm, then sign in."); return;
  }
  $("authDialog").close(); $("authForm").reset(); notify("You are signed in.");
}
async function signOut() {
  const {error} = await supabase.auth.signOut();
  if (error) notify(error.message); else notify("Signed out.");
}

$("searchInput").addEventListener("input", renderBooks);
$("categoryFilter").addEventListener("change", renderBooks);
$("bookGrid").addEventListener("click", async event => {
  const button = event.target.closest("button[data-action]"); if (!button) return;
  const {action,id} = button.dataset;
  if (action === "read") await openBook(id);
  if (action === "edit") editBook(id);
  if (action === "delete") await deleteBook(id);
});
$("bookForm").addEventListener("submit", saveBook);
$("cancelEditButton").addEventListener("click", resetBookForm);
$("authButton").addEventListener("click", () => currentUser ? signOut() : openAuth("signin"));
$("toggleAuthMode").addEventListener("click", () => openAuth(authMode === "signin" ? "signup" : "signin"));
$("authForm").addEventListener("submit", handleAuth);
$("navManage").addEventListener("click", () => $("manageSection").classList.toggle("hidden"));
$("navBrowse").addEventListener("click", () => $("browseSection").scrollIntoView({behavior:"smooth"}));
refreshSession();
